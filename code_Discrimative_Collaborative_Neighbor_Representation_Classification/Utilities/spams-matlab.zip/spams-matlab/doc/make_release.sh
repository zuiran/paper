#!/bin/bash
mkdir -p tar
mkdir -p html
make clean
make
make clean
make hevea

